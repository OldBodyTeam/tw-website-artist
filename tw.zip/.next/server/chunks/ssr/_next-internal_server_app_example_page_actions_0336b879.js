module.exports=[77172,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_example_page_actions_0336b879.js.map