var R=require("../../chunks/[turbopack]_runtime.js")("server/app/robots.txt/route.js")
R.c("server/chunks/[root-of-the-server]__48e265a0._.js")
R.c("server/chunks/[root-of-the-server]__75693397._.js")
R.c("server/chunks/_next-internal_server_app_robots_txt_route_actions_9118e90f.js")
R.m(44230)
module.exports=R.m(44230).exports
