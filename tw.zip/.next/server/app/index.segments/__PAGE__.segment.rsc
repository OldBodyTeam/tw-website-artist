1:"$Sreact.fragment"
2:I[12486,["/_next/static/chunks/b051bec46879caff.js","/_next/static/chunks/1aab279cadcaaee0.js","/_next/static/chunks/4f59f6820d63e574.js","/_next/static/chunks/9cdc2a1b2e5cebf8.js","/_next/static/chunks/a0a34b5261c165ba.js","/_next/static/chunks/76ec5479a6964ff6.js"],"HomeSwiper"]
3:I[93353,["/_next/static/chunks/4770d61a13025013.js","/_next/static/chunks/6012dc896496500f.js"],"OutletBoundary"]
4:"$Sreact.suspense"
:HL["/_next/static/chunks/8e4bf649b4ce4810.css","style"]
0:{"buildId":"yTFla5XwVcV569Q_1kNbN","rsc":["$","$1","c",{"children":[["$","div",null,{"className":"flex-1 h-screen relative","children":["$","div",null,{"className":"absolute top-0 left-0 w-full h-full","children":["$","$L2",null,{}]}]}],[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/8e4bf649b4ce4810.css","precedence":"next"}],["$","script","script-0",{"src":"/_next/static/chunks/a0a34b5261c165ba.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/76ec5479a6964ff6.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"loading":null,"isPartial":false}
5:null
