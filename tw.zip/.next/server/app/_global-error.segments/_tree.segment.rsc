1:"$Sreact.fragment"
2:I[93353,["/_next/static/chunks/4770d61a13025013.js","/_next/static/chunks/6012dc896496500f.js"],"ViewportBoundary"]
4:I[93353,["/_next/static/chunks/4770d61a13025013.js","/_next/static/chunks/6012dc896496500f.js"],"MetadataBoundary"]
5:"$Sreact.suspense"
7:I[90663,["/_next/static/chunks/4770d61a13025013.js","/_next/static/chunks/6012dc896496500f.js"],"IconMark"]
0:{"buildId":"yTFla5XwVcV569Q_1kNbN","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":false},"head":["$","$1","h",{"children":[null,["$","$L2",null,{"children":"$@3"}],["$","div",null,{"hidden":true,"children":["$","$L4",null,{"children":["$","$5",null,{"name":"Next.Metadata","children":"$@6"}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"isHeadPartial":false,"staleTime":300}
3:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
6:[["$","link","0",{"rel":"icon","href":"/favicon.ico?favicon.0b3bf435.ico","sizes":"256x256","type":"image/x-icon"}],["$","$L7","1",{}]]
