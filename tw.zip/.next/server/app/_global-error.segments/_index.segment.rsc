1:"$Sreact.fragment"
2:I[75889,["/_next/static/chunks/4770d61a13025013.js","/_next/static/chunks/6012dc896496500f.js"],"default"]
3:I[22301,["/_next/static/chunks/4770d61a13025013.js","/_next/static/chunks/6012dc896496500f.js"],"default"]
0:{"buildId":"yTFla5XwVcV569Q_1kNbN","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
