1:"$Sreact.fragment"
2:I[52793,["/_next/static/chunks/b051bec46879caff.js","/_next/static/chunks/1aab279cadcaaee0.js","/_next/static/chunks/4f59f6820d63e574.js","/_next/static/chunks/9cdc2a1b2e5cebf8.js","/_next/static/chunks/45dc968b111e271c.js"],"default"]
3:I[93353,["/_next/static/chunks/4770d61a13025013.js","/_next/static/chunks/6012dc896496500f.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"buildId":"yTFla5XwVcV569Q_1kNbN","rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","script","script-0",{"src":"/_next/static/chunks/45dc968b111e271c.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"loading":null,"isPartial":false}
5:null
